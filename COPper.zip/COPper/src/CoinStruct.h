
struct CoinRatios {
    double Ratio;
    string CoinA;
    string CoinB;
} Ratios [16];

double pennyD = .75;
double nickelD = .835;
double dimeD = .705;
double quarterD = .955;
